from music import *
from string import *
import csv

"""###  Initializing and reading data  ###"""
# reading step data
stepData = open("All-Step-Count.csv", "r")
next(stepData)       # skipping title row
# reading weather data
weatherData = open("Weather-Data.csv", "r")
next(weatherData)    # skipping title row

# initializing data arrays
sadieSteps   = []
davidSteps   = []
chiSteps     = []
lindsaySteps = []
reggieSteps  = []
tempAvgArr   = []

# reading step data and appending each value to arrays
for line in stepData:
   date, sadie, david, chi, lindsay, reggie = line.strip().split(',')
   # turning data to floats
   sadie   = float(sadie)
   david   = float(david)
   chi     = float(chi)
   lindsay = float(lindsay)
   reggie  = float(reggie)
   # appending to arrays
   sadieSteps.append(sadie)
   davidSteps.append(david)
   chiSteps.append(chi)
   lindsaySteps.append(lindsay)
   reggieSteps.append(reggie)

# reading weather data and appending each value to arrays
for line in weatherData:
   datetime, tempMin, tempMax, tempAvg, rain = line.strip().split(',')
   # turning data to floats and int
   tempAvg = float(tempAvg)
   # appending to arrays
   tempAvgArr.append(tempAvg)

stepData.close()
weatherData.close()

# checking data arrays are appended correctly
print("sadie: " + str(sadieSteps))
print("david: " + str(davidSteps))
print("chi: " + str(chiSteps))
print("lindsay: " + str(lindsaySteps))
print("reggie: " + str(reggieSteps))
print("avg temp: " + str(tempAvgArr))

"""###  Initializing music with step and weather data  ###"""
# building the score, phrases, and parts
stepsScore      = Score("Steps Sonification", 50)

# options: MUSIC_BOX, HARP, PIANO, HARP, ICE_RAIN, TAIKO
sopranoPart    = Part(MUSIC_BOX, 1)
mezzoPart      = Part(PIZZICATO_STRINGS, 2)
altoPart       = Part(PIANO, 3)
tenorPart      = Part(HARP, 4)
baritonePart   = Part(ATMOSPHERE, 5)
bassPart       = Part(ICE_RAIN, 6)
 
sopranoPhrase  = Phrase(0.0)
mezzoPhrase    = Phrase(0.25)
altoPhrase     = Phrase(0.0)
tenorPhrase    = Phrase(0.5)
baritonePhrase = Phrase(0.0)
bassPhrase     = Phrase(1)

# setting ranges of data for mapping
sadieMin   = min(sadieSteps)
sadieMax   = max(sadieSteps)
davidMin   = min(davidSteps)
davidMax   = max(davidSteps)
chiMin     = min(chiSteps)
chiMax     = max(chiSteps)
lindsayMin = min(lindsaySteps)
lindsayMax = max(lindsaySteps)
reggieMin  = min(reggieSteps)
reggieMax  = max(reggieSteps)
tAvgMin    = min(tempAvgArr)
tAvgMax    = max(tempAvgArr)

"""###  Data and instruments mixing  ###"""
# AvgTemp as BASS
i = 0
while i < len(tempAvgArr):
   avgTempPitch = mapScale(tempAvgArr[i], tAvgMin, tAvgMax, G2, G4, LYDIAN_SCALE)
   bass = Note(avgTempPitch, HN, 40)    # same logic as BASS, but starting at 4th data point
   bassPhrase.addNote(bass)             # so it uses points BASS is skipping
   i += 4

# Lindsay as BARITONE
i = 0
while i < len(lindsaySteps):
   lindsayPitch = mapScale(lindsaySteps[i], lindsayMin, lindsayMax, G2, G4, LYDIAN_SCALE)
   baritone = Note(lindsayPitch, HN, 40) # same logic as BASS, but starting at 4th data point
   baritonePhrase.addNote(baritone)      # so it uses points BASS is skipping
   i += 4

# Chi as TENOR
i = 0
while i < len(chiSteps):
   chiPitch = mapScale(chiSteps[i], chiMin, chiMax, G3, G4, LYDIAN_SCALE)
   tenor = Note(chiPitch, QN, 40)        # accompaniment so quarter note based, iterating
   tenorPhrase.addNote(tenor)            # through every 4th data point for timing
   i += 2

# Reggie as ALTO
i = 0
while i < len(reggieSteps):
   reggiePitch = mapScale(reggieSteps[i], reggieMin, reggieMax, G3, G4, LYDIAN_SCALE)
   alto = Note(reggiePitch, QN, 40)      # same logic as BASS, but starting at 4th data point
   altoPhrase.addNote(alto)              # so it uses points BASS is skipping
   i += 2

# Sadie as MEZZO
i = 0
while i < len(sadieSteps):
   sadiePitch = mapScale(sadieSteps[i], sadieMin, sadieMax, G4, G5, LYDIAN_SCALE)
   mezzo = Note(sadiePitch, EN, 40)    
   mezzoPhrase.addNote(mezzo)
   i += 1
   
# David as SOPRANO
i = 0
while i < len(davidSteps):
   davidPitch = mapScale(davidSteps[i], davidMin, davidMax, G4, G6, LYDIAN_SCALE)
   soprano = Note(davidPitch, EN, 40)    # same logic as TENOR, but starting at 2nd data
   sopranoPhrase.addNote(soprano)        # point to fill in gaps
   i += 1                                # and represents the plane traveling further away

# adding all parts and phrases together
sopranoPart.addPhrase(sopranoPhrase)
mezzoPart.addPhrase(mezzoPhrase)
altoPart.addPhrase(altoPhrase)
tenorPart.addPhrase(tenorPhrase)
baritonePart.addPhrase(baritonePhrase)
bassPart.addPhrase(bassPhrase)

stepsScore.addPart(sopranoPart)
stepsScore.addPart(mezzoPart)
stepsScore.addPart(altoPart)
stepsScore.addPart(tenorPart)
stepsScore.addPart(baritonePart)
stepsScore.addPart(bassPart)

# the product
Write.midi(stepsScore, "stepsSonification.mid")
#Play.midi(sopranoPart)
#Play.midi(mezzoPart)
#Play.midi(altoPart)
#Play.midi(tenorPart)
#Play.midi(baritonePart)
#Play.midi(bassPart)
Play.midi(stepsScore)